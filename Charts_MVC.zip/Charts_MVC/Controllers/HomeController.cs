﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Charts_MVC.Models;
namespace Charts_MVC.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            string query = "SELECT ShipCity, COUNT(orderid) TotalOrders";
            query += " FROM Orders WHERE ShipCountry = 'USA' GROUP BY ShipCity";
            string constr = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
            List<OrderModel> chartData = new List<OrderModel>();

            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.CommandType = CommandType.Text;
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            chartData.Add(new OrderModel
                            {
                                ShipCity = sdr["ShipCity"].ToString(),
                                TotalOrders = Convert.ToInt32(sdr["TotalOrders"])
                            });
                        }
                    }

                    con.Close();
                }
            }

            return View(chartData);
        }
    }
}
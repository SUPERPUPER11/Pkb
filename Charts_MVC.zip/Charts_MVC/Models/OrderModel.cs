﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Charts_MVC.Models
{
    public class OrderModel
    {
        public string ShipCity { get; set; }
        public int TotalOrders { get; set; }
    }
}